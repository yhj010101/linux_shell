#!/bin/bash
#arithmetic operaiton
read -p "Input two numbers : " num1 num2

echo "num1=$num1, num2=$num2"
echo
echo "Add = $[$num1 + $num2]"
echo "Sub = $[$num1 - $num2]"
echo "Mul = $[$num1 * $num2]"
echo "Div = $[$num1 / $num2]"
echo "Modulo = $[$num2 % $num1]"

