#!/bin/bash
# wild character used in for loops

for str in *.sh
do
	echo $str; 
done


