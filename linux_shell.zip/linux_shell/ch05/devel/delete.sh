#!/bin/bash
CC=gcc
CFLAGS="-g -c -O2 -Wall"

echo "Project Tempory File Delete..."

echo ""
echo "Delete All Object & Executable File~~"
rm mytest *.o

echo ""
echo "Delete Completed!!"

exit 0

