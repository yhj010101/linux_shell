#!/bin/bash
echo "The login user is $SUDO_USER"

echo "The login user is ${SUDO_USER:-$USER}"
echo "The login user is ${SUDO_USER:-$(whoami)}"

