#!/bin/bash
name="educafe"
age=5
echo $name
echo "$name"
echo '$name'
echo \$name
unset name
echo $USER

