#!/bin/bash
# This is comment line

echo $PPID $$ $BASHPID $BASH_SUBSHELL

(echo $PPID $$ $BASHPID $BASH_SUBSHELL)





